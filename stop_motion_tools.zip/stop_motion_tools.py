bl_info = {
    "name": "Stop Motion Stepper",
    "author": "Your Name / AI Collaborator",
    "version": (1, 4),
    "blender": (5, 0, 0),
    "location": "View3D > Sidebar > Stop Motion Tools",
    "description": "Thins keyframes and applies stepped holds for bones or regular objects.",
    "category": "Animation",
}

import bpy
from bpy_extras import anim_utils


def thin_and_step_channelbag(channelbag, frames_to_delete, data_path_filter=None):
    """Helper function to thin keyframes and set constant interpolation on an F-Curve container."""
    modified_curves = 0
    
    for fcurve in channelbag.fcurves:
        # If a path filter is provided, skip non-matching curves
        if data_path_filter is not None:
            if not any(path in fcurve.data_path for path in data_path_filter):
                continue

        points = fcurve.keyframe_points
        
        # Iterate BACKWARDS by index to keep C memory pointers valid during deletion
        for i in range(len(points) - 1, -1, -1):
            kp = points[i]
            frame_num = int(round(kp.co[0]))  # Round float to nearest integer frame
            
            if frame_num in frames_to_delete:
                points.remove(kp)
                
        # Set remaining keyframes to CONSTANT interpolation for the stepped hold
        for kp in points:
            kp.interpolation = 'CONSTANT'
            
        modified_curves += 1
        
    return modified_curves


class ANIM_OT_stop_motion_step_bones(bpy.types.Operator):
    """Thin out keyframes on selected POSE BONES (Works with ARP baked FK)"""
    bl_idname = "anim.stop_motion_step_bones"
    bl_label = "Step Selected Bones"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        obj = context.active_object
        
        if not obj or obj.type != 'ARMATURE':
            self.report({'ERROR'}, "Active object must be an Armature!")
            return {'CANCELLED'}
            
        selected_bones = context.selected_pose_bones
        if not selected_bones:
            self.report({'ERROR'}, "Please select at least one bone in Pose Mode!")
            return {'CANCELLED'}

        if not obj.animation_data or not obj.animation_data.action:
            self.report({'ERROR'}, "No active action found on this armature.")
            return {'CANCELLED'}

        anim_data = obj.animation_data
        channelbag = anim_utils.action_get_channelbag_for_slot(anim_data.action, anim_data.action_slot)
        
        if not channelbag or not channelbag.fcurves:
            self.report({'ERROR'}, "No animation curves found in the current slot.")
            return {'CANCELLED'}

        frame_step = scene.stop_motion_step
        start_frame = scene.frame_start
        end_frame = scene.frame_end

        frames_to_delete = {
            f for f in range(start_frame, end_frame + 1)
            if (f - start_frame) % frame_step != 0
        }

        selected_bone_paths = {f'pose.bones["{b.name}"]' for b in selected_bones}
        
        count = thin_and_step_channelbag(channelbag, frames_to_delete, selected_bone_paths)

        if count == 0:
            self.report({'WARNING'}, "No keyframes were found on the selected bones.")
            return {'CANCELLED'}

        self.report({'INFO'}, f"Stepped {count} bone curves every {frame_step} frames!")
        return {'FINISHED'}


class ANIM_OT_stop_motion_step_objects(bpy.types.Operator):
    """Bake and thin keyframes on SELECTED OBJECTS (Cameras, Props, Nulls, etc.)"""
    bl_idname = "anim.stop_motion_step_objects"
    bl_label = "Bake & Step Selected Objects"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        selected_objs = context.selected_objects

        if not selected_objs:
            self.report({'ERROR'}, "Please select at least one Object!")
            return {'CANCELLED'}

        frame_step = scene.stop_motion_step
        start_frame = scene.frame_start
        end_frame = scene.frame_end

        # Step 1: Bake Object Transforms
        bpy.ops.nla.bake(
            frame_start=start_frame,
            frame_end=end_frame,
            step=1,
            only_selected=True,
            visual_keying=True,
            clear_constraints=False,
            clear_parents=False,
            bake_types={'OBJECT'}
        )

        frames_to_delete = {
            f for f in range(start_frame, end_frame + 1)
            if (f - start_frame) % frame_step != 0
        }

        total_modified = 0

        # Step 2: Iterate through selected objects and thin out their curves
        for obj in selected_objs:
            if not obj.animation_data or not obj.animation_data.action:
                continue

            anim_data = obj.animation_data
            channelbag = anim_utils.action_get_channelbag_for_slot(anim_data.action, anim_data.action_slot)
            
            if channelbag and channelbag.fcurves:
                total_modified += thin_and_step_channelbag(channelbag, frames_to_delete, data_path_filter=None)

        if total_modified == 0:
            self.report({'WARNING'}, "No object keyframes found to step.")
            return {'CANCELLED'}

        self.report({'INFO'}, f"Baked & stepped {len(selected_objs)} object(s) every {frame_step} frames!")
        return {'FINISHED'}


class ANIM_PT_stop_motion_panel(bpy.types.Panel):
    """Creates a Panel in the 3D View Sidebar"""
    bl_label = "Stop Motion Stepper"
    bl_idname = "ANIM_PT_stop_motion_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Stop Motion Tools'

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        col = layout.column(align=True)
        col.label(text="Global Settings:")
        col.prop(scene, "stop_motion_step", text="Keep Every X Frames")
        col.label(text=f"Range: {scene.frame_start} to {scene.frame_end}")
        
        layout.separator()

        box_bones = layout.box()
        box_bones.label(text="Armatures / Bones:", icon='BONE_DATA')
        box_bones.operator("anim.stop_motion_step_bones", icon='POSE_HLT')

        box_objs = layout.box()
        box_objs.label(text="Objects (Props / Cameras / Nulls):", icon='OBJECT_DATA')
        box_objs.operator("anim.stop_motion_step_objects", icon='CAMERA_DATA')


def register():
    bpy.types.Scene.stop_motion_step = bpy.props.IntProperty(
        name="Frame Step",
        description="The interval of frames to keep (e.g., 2 = animate on 2s)",
        default=2,
        min=2,
        max=24
    )
    bpy.utils.register_class(ANIM_OT_stop_motion_step_bones)
    bpy.utils.register_class(ANIM_OT_stop_motion_step_objects)
    bpy.utils.register_class(ANIM_PT_stop_motion_panel)

def unregister():
    bpy.utils.unregister_class(ANIM_PT_stop_motion_panel)
    bpy.utils.unregister_class(ANIM_OT_stop_motion_step_objects)
    bpy.utils.unregister_class(ANIM_OT_stop_motion_step_bones)
    del bpy.types.Scene.stop_motion_step

if __name__ == "__main__":
    register()